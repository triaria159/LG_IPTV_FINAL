from fastapi import APIRouter, Request
from services.recommendation import get_recommendations
from services.youtube import search_youtube_videos
from fastapi.responses import HTMLResponse
import templates
router = APIRouter()

@router.get("/추천", response_class=HTMLResponse)
async def recommend(request: Request):
    user_keywords = ["example_keyword"]  # Replace with dynamic user data
    search_results = search_youtube_videos(user_keywords)
    recommendations = get_recommendations(search_results, user_keywords)
    return templates.TemplateResponse(
        "추천.html",
        {"request": request, "recommendations": recommendations}
    )
