from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, HTMLResponse
from services.youtube import get_video_details, record_watch_time
from pydantic import BaseModel
import templates

router = APIRouter()

watch_records = {}

class WatchRecord(BaseModel):
    videoId: str
    watchedTime: int
    duration: int

@router.get("/video_details/{video_id}", response_class=HTMLResponse)
async def video_details(video_id: str, request: Request):
    video_data = get_video_details(video_id)
    if not video_data:
        return HTMLResponse("영상 정보를 찾을 수 없습니다.", status_code=404)
    return templates.TemplateResponse(
        "video_watch.html",
        {"request": request, "video": video_data}
    )

@router.post("/record_watch")
async def record_watch(data: WatchRecord):
    watch_records[data.videoId] = record_watch_time(data.videoId, data.watchedTime, data.duration, watch_records)
    return JSONResponse(watch_records[data.videoId])
