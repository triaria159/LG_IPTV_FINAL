from fastapi import APIRouter, Form, Request
from fastapi.responses import RedirectResponse
from starlette.datastructures import URL
from fastapi.responses import HTMLResponse
import templates

router = APIRouter()

# In-memory storage for user data
user_data = {}

@router.post("/save_user_data")
async def save_user_data(
    age: int = Form(...),
    height: float = Form(...),
    weight: float = Form(...),
    interest: list[str] = Form([]),
    custom_interest: str = Form("")
):
    user_data.update({
        "age": age,
        "height": height,
        "weight": weight,
        "interest": interest,
        "customInterest": custom_interest
    })
    return RedirectResponse(url="/확인", status_code=303)

@router.get("/확인", response_class=HTMLResponse)
async def check_data(request: Request):
    return templates.TemplateResponse("확인.html", {"request": request, "user_data": user_data})
