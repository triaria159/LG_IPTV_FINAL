import os
from dotenv import load_dotenv

# 환경 변수 로드
load_dotenv()

# YouTube API 키
YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY", "your_api_key_here")
